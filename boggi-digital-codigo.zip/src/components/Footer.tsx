export function Footer() {
  return (
    <footer className="border-t border-hairline bg-canvas py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 px-6 sm:flex-row sm:items-center lg:px-10">
        <div>
          <a
            href="#inicio"
            className="font-display text-base font-bold tracking-tight text-ink whitespace-nowrap"
          >
            BOGGI DIGITAL
          </a>
          <p className="mt-1.5 text-xs text-muted">
            © 2026 Boggi Digital. Criação de sites sob medida.
          </p>
        </div>

        <nav
          aria-label="Links do rodapé"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-muted"
        >
          <a
            href="#inicio"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            Início
          </a>
          <a
            href="#servicos"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            Serviços
          </a>
          <a
            href="#planos"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            Planos
          </a>
          <a
            href="#contato"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            Contato
          </a>
        </nav>

        <div className="flex items-center gap-5 text-xs font-medium text-muted">
          <a
            href="https://www.linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            LinkedIn
          </a>
          <a
            href="https://www.instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            Instagram
          </a>
          <a
            href="https://www.youtube.com"
            target="_blank"
            rel="noopener noreferrer"
            className="transition-colors hover:text-ink whitespace-nowrap"
          >
            YouTube
          </a>
        </div>
      </div>
    </footer>
  );
}
