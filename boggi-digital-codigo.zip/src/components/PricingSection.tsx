import { ArrowRight, Check } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { PRICING_PLANS } from '../data/agencyData';

interface PricingSectionProps {
  onSelectPlan: (planOptionValue: string) => void;
}

export function PricingSection({ onSelectPlan }: PricingSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="planos"
      className="border-b border-hairline py-24 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Centered / Editorial Header */}
        <motion.div
          initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-2xl"
        >
          <p className="text-sm font-medium tracking-wide text-brand">
            Valores transparentes
          </p>
          <h2 className="mt-3 font-display text-[clamp(2rem,3.6vw,3.25rem)] font-bold leading-[1.08] tracking-tight text-ink">
            Escolha o nível ideal para o seu site
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted">
            Três formatos claros e diretos — sem letras miúdas, com foco total
            em estética, velocidade e conversão.
          </p>
        </motion.div>

        {/* 3-Tier Architectural Pricing Grid */}
        <div className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-3 lg:items-stretch">
          {PRICING_PLANS.map((plan, idx) => {
            const isRecommended = Boolean(plan.recommended);

            return (
              <motion.article
                key={plan.id}
                initial={
                  prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }
                }
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.6,
                  delay: prefersReducedMotion ? 0 : idx * 0.06,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`flex flex-col justify-between rounded-xl border p-8 lg:p-9 ${
                  isRecommended
                    ? 'border-brand/60 bg-elevated'
                    : 'border-hairline bg-surface'
                }`}
              >
                <div>
                  {/* Unboxed kicker + Plan Name */}
                  <div className="flex items-baseline justify-between gap-4">
                    <h3 className="font-display text-2xl font-semibold tracking-tight text-ink">
                      {plan.name}
                    </h3>
                    <span
                      className={`text-xs font-medium ${
                        isRecommended ? 'text-brand' : 'text-muted'
                      }`}
                    >
                      {plan.tierLabel}
                    </span>
                  </div>

                  {/* Price */}
                  <div className="mt-6 border-b border-hairline pb-6">
                    <div className="flex items-baseline gap-2">
                      <span className="font-mono text-4xl font-medium tracking-tight text-ink tabular-nums sm:text-5xl">
                        {plan.price}
                      </span>
                      <span className="text-xs text-muted">projeto único</span>
                    </div>
                    <p className="mt-4 text-sm leading-relaxed text-muted">
                      {plan.summary}
                    </p>
                  </div>

                  {/* Deliverables */}
                  <ul className="mt-6 space-y-3.5">
                    {plan.features.map((feature) => (
                      <li
                        key={feature}
                        className="flex items-start gap-3 text-sm leading-relaxed text-ink/90"
                      >
                        <Check
                          className={`mt-0.5 h-4 w-4 shrink-0 ${
                            isRecommended ? 'text-brand' : 'text-secondary'
                          }`}
                          aria-hidden="true"
                        />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA */}
                <div className="mt-10 pt-4">
                  <button
                    type="button"
                    onClick={() => onSelectPlan(plan.optionValue)}
                    className={`group inline-flex min-h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-lg px-6 py-3 text-sm font-medium transition-colors duration-150 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand ${
                      isRecommended
                        ? 'bg-brand text-white hover:bg-brand/90'
                        : 'border border-hairline bg-canvas text-ink hover:border-brand/60 hover:bg-elevated'
                    }`}
                  >
                    <span>{plan.ctaLabel}</span>
                    <ArrowRight
                      className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5"
                      aria-hidden="true"
                    />
                  </button>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
