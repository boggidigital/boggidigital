import { useEffect, useState, type FormEvent } from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { PRICING_PLANS } from '../data/agencyData';

interface ContactSectionProps {
  selectedPlan: string;
  nameInputRef: React.RefObject<HTMLInputElement | null>;
}

interface FormState {
  name: string;
  email: string;
  business: string;
  plan: string;
  details: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  business?: string;
  details?: string;
}

export function ContactSection({
  selectedPlan,
  nameInputRef,
}: ContactSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  const [form, setForm] = useState<FormState>({
    name: '',
    email: '',
    business: '',
    plan: selectedPlan || PRICING_PLANS[1].optionValue,
    details: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (selectedPlan) {
      setForm((prev) => ({ ...prev, plan: selectedPlan }));
      setSubmitted(false);
    }
  }, [selectedPlan]);

  const validate = (): FormErrors => {
    const nextErrors: FormErrors = {};
    if (form.name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      nextErrors.email = 'Digite um e-mail válido para contato.';
    }
    if (form.business.trim().length < 2) {
      nextErrors.business = 'Informe sua profissão ou nome do negócio.';
    }
    if (form.details.trim().length < 10) {
      nextErrors.details = 'Conte em poucas palavras o que precisa no site.';
    }
    return nextErrors;
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setSubmitted(true);
  };

  const handleReset = () => {
    setForm({
      name: '',
      email: '',
      business: '',
      plan: selectedPlan || PRICING_PLANS[1].optionValue,
      details: '',
    });
    setErrors({});
    setSubmitted(false);
  };

  return (
    <section id="contato" className="relative overflow-hidden py-24 lg:py-32">
      {/* Focused subtle secondary accent glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-32 left-1/3 h-[380px] w-[380px] rounded-full bg-secondary/12 blur-[140px]"
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Editorial CTA Column */}
          <motion.div
            initial={
              prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }
            }
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-5"
          >
            <div>
              <p className="text-sm font-medium tracking-wide text-secondary">
                Solicite seu projeto
              </p>
              <h2 className="mt-3 font-display text-[clamp(2.25rem,4vw,3.5rem)] font-bold leading-[1.06] tracking-tight text-ink">
                Pronto para ter seu site?
              </h2>
              <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
                Escolha o plano ideal para o seu momento e envie sua ideia.
                Retornamos com os próximos passos para colocar seu site no ar.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
                <span>Simples R$ 300</span>
                <span aria-hidden="true">·</span>
                <span>Médio R$ 600</span>
                <span aria-hidden="true">·</span>
                <span>Premium R$ 1.000</span>
              </div>
            </div>

            <div className="mt-12 border-t border-hairline pt-6">
              <p className="text-xs font-medium text-muted">Redes sociais</p>
              <div className="mt-3 flex items-center gap-6 text-sm font-medium">
                <a
                  href="https://www.linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-ink transition-colors duration-150 hover:text-brand focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand"
                >
                  LinkedIn
                </a>
                <a
                  href="https://www.instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-ink transition-colors duration-150 hover:text-brand focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand"
                >
                  Instagram
                </a>
                <a
                  href="https://www.youtube.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-ink transition-colors duration-150 hover:text-brand focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand"
                >
                  YouTube
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right Lead Capture Form */}
          <motion.div
            initial={
              prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }
            }
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{
              duration: 0.6,
              delay: prefersReducedMotion ? 0 : 0.08,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="lg:col-span-7"
          >
            <div className="rounded-xl border border-hairline bg-surface p-7 sm:p-10">
              {submitted ? (
                <div
                  role="status"
                  aria-live="polite"
                  className="flex flex-col items-start py-6"
                >
                  <CheckCircle2
                    className="h-8 w-8 text-brand"
                    aria-hidden="true"
                  />
                  <h3 className="mt-5 font-display text-2xl font-semibold tracking-tight text-ink">
                    Pedido enviado com sucesso
                  </h3>
                  <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted sm:text-base">
                    Obrigado, <strong className="text-ink">{form.name}</strong>.
                    Recebemos seu interesse no plano{' '}
                    <strong className="text-ink">{form.plan}</strong> para{' '}
                    <strong className="text-ink">{form.business}</strong> e
                    entraremos em contato pelo e-mail{' '}
                    <strong className="text-ink">{form.email}</strong>.
                  </p>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="mt-8 inline-flex min-h-11 cursor-pointer items-center justify-center rounded-lg border border-hairline bg-elevated px-5 py-2.5 text-sm font-medium text-ink transition-colors duration-150 hover:border-brand/50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
                  >
                    Enviar outro pedido
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  noValidate
                  className="grid grid-cols-1 gap-6 sm:grid-cols-2"
                >
                  <div>
                    <label
                      htmlFor="lead-name"
                      className="block text-xs font-medium text-ink"
                    >
                      Nome completo
                    </label>
                    <input
                      ref={nameInputRef}
                      id="lead-name"
                      name="name"
                      type="text"
                      autoComplete="name"
                      required
                      value={form.name}
                      onChange={(e) => {
                        setForm((prev) => ({ ...prev, name: e.target.value }));
                        if (errors.name) {
                          setErrors((prev) => ({ ...prev, name: undefined }));
                        }
                      }}
                      placeholder="Ex.: Lucas Almeida"
                      aria-invalid={Boolean(errors.name)}
                      className="mt-2 block min-h-11 w-full rounded-lg border border-hairline bg-canvas px-4 py-2.5 text-sm text-ink placeholder:text-muted/60 transition-colors focus:border-brand focus:outline-none"
                    />
                    {errors.name && (
                      <p className="mt-1.5 text-xs text-red-400">
                        {errors.name}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="lead-email"
                      className="block text-xs font-medium text-ink"
                    >
                      Seu melhor e-mail
                    </label>
                    <input
                      id="lead-email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      value={form.email}
                      onChange={(e) => {
                        setForm((prev) => ({ ...prev, email: e.target.value }));
                        if (errors.email) {
                          setErrors((prev) => ({ ...prev, email: undefined }));
                        }
                      }}
                      placeholder="voce@email.com"
                      aria-invalid={Boolean(errors.email)}
                      className="mt-2 block min-h-11 w-full rounded-lg border border-hairline bg-canvas px-4 py-2.5 text-sm text-ink placeholder:text-muted/60 transition-colors focus:border-brand focus:outline-none"
                    />
                    {errors.email && (
                      <p className="mt-1.5 text-xs text-red-400">
                        {errors.email}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="lead-business"
                      className="block text-xs font-medium text-ink"
                    >
                      Profissão ou negócio
                    </label>
                    <input
                      id="lead-business"
                      name="business"
                      type="text"
                      required
                      value={form.business}
                      onChange={(e) => {
                        setForm((prev) => ({
                          ...prev,
                          business: e.target.value,
                        }));
                        if (errors.business) {
                          setErrors((prev) => ({
                            ...prev,
                            business: undefined,
                          }));
                        }
                      }}
                      placeholder="Ex.: Psicóloga, Loja, Arquiteto"
                      aria-invalid={Boolean(errors.business)}
                      className="mt-2 block min-h-11 w-full rounded-lg border border-hairline bg-canvas px-4 py-2.5 text-sm text-ink placeholder:text-muted/60 transition-colors focus:border-brand focus:outline-none"
                    />
                    {errors.business && (
                      <p className="mt-1.5 text-xs text-red-400">
                        {errors.business}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="lead-plan"
                      className="block text-xs font-medium text-ink"
                    >
                      Plano escolhido
                    </label>
                    <select
                      id="lead-plan"
                      name="plan"
                      value={form.plan}
                      onChange={(e) =>
                        setForm((prev) => ({
                          ...prev,
                          plan: e.target.value,
                        }))
                      }
                      className="mt-2 block min-h-11 w-full rounded-lg border border-hairline bg-canvas px-4 py-2.5 text-sm text-ink transition-colors focus:border-brand focus:outline-none"
                    >
                      {PRICING_PLANS.map((plan) => (
                        <option key={plan.id} value={plan.optionValue}>
                          {plan.optionValue}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label
                      htmlFor="lead-details"
                      className="block text-xs font-medium text-ink"
                    >
                      Como você imagina o seu site?
                    </label>
                    <textarea
                      id="lead-details"
                      name="details"
                      rows={3}
                      required
                      value={form.details}
                      onChange={(e) => {
                        setForm((prev) => ({
                          ...prev,
                          details: e.target.value,
                        }));
                        if (errors.details) {
                          setErrors((prev) => ({
                            ...prev,
                            details: undefined,
                          }));
                        }
                      }}
                      placeholder="Conte o que você quer mostrar no site (serviços, fotos, contatos) e qualquer referência que goste."
                      aria-invalid={Boolean(errors.details)}
                      className="mt-2 block w-full rounded-lg border border-hairline bg-canvas px-4 py-3 text-sm text-ink placeholder:text-muted/60 transition-colors focus:border-brand focus:outline-none"
                    />
                    {errors.details && (
                      <p className="mt-1.5 text-xs text-red-400">
                        {errors.details}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col items-start justify-between gap-4 pt-2 sm:col-span-2 sm:flex-row sm:items-center">
                    <span className="text-xs text-muted">
                      Orçamento sem compromisso.
                    </span>
                    <button
                      type="submit"
                      className="group inline-flex min-h-12 w-full cursor-pointer items-center justify-center gap-2.5 rounded-lg bg-brand px-7 py-3.5 text-sm font-medium text-white transition-colors duration-150 hover:bg-brand/90 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand sm:w-auto"
                    >
                      <span>Solicitar Meu Site</span>
                      <ArrowRight
                        className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5"
                        aria-hidden="true"
                      />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
