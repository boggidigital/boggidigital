import { ArrowUpRight } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { WEB_CAPABILITIES } from '../data/agencyData';
import { EditorialImage } from './EditorialImage';

interface ServicesSectionProps {
  onExplorePlans: () => void;
}

export function ServicesSection({ onExplorePlans }: ServicesSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="servicos"
      className="border-b border-hairline py-24 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        {/* Editorial Section Header */}
        <motion.div
          initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-end"
        >
          <div className="lg:col-span-7">
            <p className="text-sm font-medium tracking-wide text-secondary">
              O que você recebe
            </p>
            <h2 className="mt-3 font-display text-[clamp(2rem,3.6vw,3.25rem)] font-bold leading-[1.08] tracking-tight text-ink">
              Sites pensados para pessoas reais
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-base leading-relaxed text-muted">
              Cada projeto nasce para apresentar seu trabalho com credibilidade,
              abrir rápido no celular e transformar visitas em mensagens.
            </p>
          </div>
        </motion.div>

        {/* Asymmetric 12-Column Bento Grid */}
        <div className="mt-14 grid grid-cols-1 gap-6 lg:grid-cols-12">
          {WEB_CAPABILITIES.map((item, idx) => {
            const hasImage = Boolean(item.image);

            return (
              <motion.article
                key={item.id}
                initial={
                  prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }
                }
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.6,
                  delay: prefersReducedMotion ? 0 : idx * 0.05,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`${item.spanClass} group relative overflow-hidden rounded-xl border border-hairline bg-surface transition-colors duration-200 hover:border-brand/50`}
              >
                <button
                  type="button"
                  onClick={onExplorePlans}
                  className="flex h-full w-full cursor-pointer flex-col justify-between text-left focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-brand"
                >
                  {hasImage && item.image ? (
                    <div className="relative flex min-h-[320px] w-full flex-col justify-between p-7 sm:min-h-[340px] lg:p-9">
                      <EditorialImage
                        src={item.image}
                        alt={item.imageAlt ?? item.title}
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                      />
                      <div
                        aria-hidden="true"
                        className="absolute inset-0 bg-gradient-to-t from-canvas via-canvas/85 to-canvas/45"
                      />

                      <div className="relative z-10 flex items-center justify-between gap-4">
                        <span className="text-xs font-medium text-muted">
                          {item.subtitle}
                        </span>
                        <ArrowUpRight
                          className="h-5 w-5 shrink-0 text-ink/70 transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-brand"
                          aria-hidden="true"
                        />
                      </div>

                      <div className="relative z-10 mt-16">
                        <h3 className="font-display text-2xl font-semibold tracking-tight text-ink sm:text-3xl">
                          {item.index}. {item.title}
                        </h3>
                        <p className="mt-3 max-w-lg text-sm leading-relaxed text-ink/85 sm:text-base">
                          {item.description}
                        </p>
                        <div className="mt-5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
                          <span>{item.deliverables[0]}</span>
                          <span aria-hidden="true">·</span>
                          <span>{item.deliverables[1]}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex h-full min-h-[260px] flex-col justify-between p-7 lg:p-9">
                      <div className="flex items-center justify-between gap-4">
                        <span className="text-xs font-medium text-muted">
                          {item.subtitle}
                        </span>
                        <ArrowUpRight
                          className="h-5 w-5 shrink-0 text-muted transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-brand"
                          aria-hidden="true"
                        />
                      </div>

                      <div className="mt-12">
                        <h3 className="font-display text-2xl font-semibold tracking-tight text-ink">
                          {item.index}. {item.title}
                        </h3>
                        <p className="mt-3 text-sm leading-relaxed text-muted sm:text-base">
                          {item.description}
                        </p>
                        <div className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-hairline pt-4 text-xs text-muted">
                          <span>{item.deliverables[0]}</span>
                          <span aria-hidden="true">·</span>
                          <span>{item.deliverables[1]}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </button>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
