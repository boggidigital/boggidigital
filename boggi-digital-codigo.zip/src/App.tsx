import { useRef, useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { PricingSection } from './components/PricingSection';
import { ProcessSection } from './components/ProcessSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { PRICING_PLANS } from './data/agencyData';

export default function App() {
  const [selectedPlan, setSelectedPlan] = useState<string>(
    PRICING_PLANS[1].optionValue,
  );
  const nameInputRef = useRef<HTMLInputElement | null>(null);

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollToContact = (planOptionValue?: string) => {
    if (planOptionValue) {
      setSelectedPlan(planOptionValue);
    }
    scrollToSection('contato');
    window.setTimeout(() => {
      nameInputRef.current?.focus({ preventScroll: true });
    }, 350);
  };

  return (
    <div className="min-h-screen bg-canvas text-ink">
      <Navbar onRequestSite={() => scrollToContact()} />
      <main>
        <HeroSection onRequestSite={() => scrollToContact()} />
        <ServicesSection onExplorePlans={() => scrollToSection('planos')} />
        <PricingSection onSelectPlan={(plan) => scrollToContact(plan)} />
        <ProcessSection />
        <ContactSection
          selectedPlan={selectedPlan}
          nameInputRef={nameInputRef}
        />
      </main>
      <Footer />
    </div>
  );
}
