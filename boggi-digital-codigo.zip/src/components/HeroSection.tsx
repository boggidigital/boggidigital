import { ArrowRight } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { OVERVIEW_HIGHLIGHTS } from '../data/agencyData';
import { EditorialImage } from './EditorialImage';

interface HeroSectionProps {
  onRequestSite: () => void;
}

export function HeroSection({ onRequestSite }: HeroSectionProps) {
  const prefersReducedMotion = useReducedMotion();

  const initialFade = prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 18 };
  const animateFade = { opacity: 1, y: 0 };
  const transition = { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const };

  return (
    <section
      id="inicio"
      className="relative overflow-hidden border-b border-hairline pt-28 pb-16 lg:pt-36 lg:pb-20"
    >
      {/* Subtle architectural ambient gradient behind hero */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 right-0 h-[520px] w-[520px] rounded-full bg-brand/10 blur-[140px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-0 left-0 h-[420px] w-[420px] rounded-full bg-secondary/10 blur-[140px]"
      />

      <div className="relative mx-auto max-w-7xl px-6 lg:px-10">
        {/* Asymmetric Hero Split */}
        <div className="grid grid-cols-1 items-stretch gap-12 lg:grid-cols-12 lg:gap-14">
          <motion.div
            initial={initialFade}
            animate={animateFade}
            transition={transition}
            className="flex flex-col justify-center lg:col-span-6"
          >
            <p className="text-sm font-medium tracking-wide text-brand">
              Criação de sites sob medida
            </p>

            <h1 className="mt-4 font-display text-[clamp(2.5rem,4.8vw,4.5rem)] font-bold leading-[1.03] tracking-tight text-ink">
              Sites Profissionais para Você
            </h1>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
              Criamos páginas rápidas, bonitas e responsivas para pessoas,
              autônomos e empresas conquistarem clientes — com planos claros a
              partir de R$ 300.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-6">
              <button
                type="button"
                onClick={onRequestSite}
                className="group inline-flex min-h-12 cursor-pointer items-center gap-2.5 rounded-lg bg-brand px-7 py-3.5 text-sm font-medium text-white transition-all duration-150 hover:bg-brand/90 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand"
              >
                <span>Solicitar Meu Site</span>
                <ArrowRight
                  className="h-4 w-4 transition-transform duration-150 group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </button>

              <a
                href="#planos"
                className="inline-flex min-h-12 items-center text-sm font-medium text-ink/85 transition-colors duration-150 hover:text-ink whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand"
              >
                Ver planos e valores
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ ...transition, delay: prefersReducedMotion ? 0 : 0.08 }}
            className="lg:col-span-6"
          >
            <div className="relative aspect-[16/10] w-full overflow-hidden rounded-xl border border-hairline bg-surface lg:aspect-auto lg:h-full lg:min-h-[460px]">
              <EditorialImage
                src="/src/assets/images/hero_agency_strategy_1794926726387.jpg"
                alt="Equipe planejando a estrutura e o design de um novo site profissional"
                priority
                className="h-full w-full object-cover"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/80 via-canvas/20 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-4 px-6 py-5">
                <span className="text-xs font-medium text-ink/90">
                  Design · Velocidade · Responsividade
                </span>
                <span className="font-mono text-xs text-muted tabular-nums">
                  Simples · Médio · Premium
                </span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-width 4-Column Pricing & Standard Strip */}
        <motion.div
          initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.25 }}
          transition={transition}
          className="mt-16 grid grid-cols-2 divide-y divide-hairline overflow-hidden rounded-xl border border-hairline bg-surface sm:grid-cols-4 sm:divide-x sm:divide-y-0 lg:mt-20"
        >
          {OVERVIEW_HIGHLIGHTS.map((item) => (
            <div
              key={item.label}
              className="flex flex-col justify-between px-6 py-7 lg:px-8 lg:py-8"
            >
              <span className="font-mono text-3xl font-medium tracking-tight text-ink tabular-nums sm:text-4xl">
                {item.value}
              </span>
              <div className="mt-3">
                <p className="text-sm font-medium text-ink">{item.label}</p>
                <p className="mt-0.5 text-xs text-muted">{item.context}</p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
