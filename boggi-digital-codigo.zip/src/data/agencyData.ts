export interface OverviewItem {
  value: string;
  label: string;
  context: string;
}

export interface CapabilityItem {
  id: string;
  index: string;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  spanClass: string;
  image?: string;
  imageAlt?: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  optionValue: string;
  price: string;
  tierLabel: string;
  summary: string;
  features: string[];
  recommended?: boolean;
  ctaLabel: string;
}

export interface ProcessStep {
  index: string;
  title: string;
  description: string;
}

export const OVERVIEW_HIGHLIGHTS: OverviewItem[] = [
  {
    value: 'R$ 300',
    label: 'Plano Simples',
    context: 'Página única direta ao ponto',
  },
  {
    value: 'R$ 600',
    label: 'Plano Médio',
    context: 'Site completo multi-seções',
  },
  {
    value: 'R$ 1.000',
    label: 'Plano Premium',
    context: 'Projeto exclusivo e completo',
  },
  {
    value: '100%',
    label: 'Responsivo',
    context: 'Adaptado para celular e desktop',
  },
];

export const WEB_CAPABILITIES: CapabilityItem[] = [
  {
    id: 'design-responsivo',
    index: '01',
    title: 'Design Responsivo',
    subtitle: 'Celular · Tablet · Desktop',
    description:
      'Todo site é projetado para abrir rápido e funcionar com leitura perfeita em qualquer tela, especialmente no celular.',
    deliverables: ['Layout fluido', 'Navegação intuitiva'],
    spanClass: 'lg:col-span-7',
    image: '/src/assets/images/service_web_creation_1794927263497.jpg',
    imageAlt:
      'Web designer ajustando um site responsivo exibido em notebook e smartphone lado a lado',
  },
  {
    id: 'estrutura-conversao',
    index: '02',
    title: 'Foco em Contato',
    subtitle: 'Clareza · Botões · Formulário',
    description:
      'Organizamos suas informações e chamadas para ação de forma objetiva para facilitar o contato de novos clientes.',
    deliverables: ['Texto enxuto', 'Formulário validado'],
    spanClass: 'lg:col-span-5',
  },
  {
    id: 'identidade-visual',
    index: '03',
    title: 'Visual Sob Medida',
    subtitle: 'Cores · Tipografia · Estilo',
    description:
      'Nada de modelos genéricos. Aplicamos uma estética moderna, limpa e alinhada à sua profissão ou marca pessoal.',
    deliverables: ['Paleta dedicada', 'Hierarquia tipográfica'],
    spanClass: 'lg:col-span-5',
  },
  {
    id: 'velocidade-seo',
    index: '04',
    title: 'Velocidade e SEO',
    subtitle: 'Performance · Google · Código limpo',
    description:
      'Estrutura técnica otimizada para carregamento leve, boas práticas de indexação e compartilhamento profissional em redes.',
    deliverables: ['Carregamento rápido', 'Tags SEO configuradas'],
    spanClass: 'lg:col-span-7',
    image: '/src/assets/images/service_branding_studio_1794926727460.jpg',
    imageAlt:
      'Diretora de design organizando paleta de cores e estrutura visual de um projeto web',
  },
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'simples',
    name: 'Simples',
    optionValue: 'Simples — R$ 300',
    price: 'R$ 300',
    tierLabel: 'Presença essencial',
    summary:
      'Ideal para profissionais autônomos e quem precisa de uma página direta para apresentar seu trabalho.',
    features: [
      'Página única (landing page) objetiva',
      'Design responsivo para celular e computador',
      'Apresentação clara do seu serviço',
      'Botões de ação e formulário de contato',
      'SEO básico com título e descrição',
    ],
    ctaLabel: 'Escolher Plano Simples',
  },
  {
    id: 'medio',
    name: 'Médio',
    optionValue: 'Médio — R$ 600',
    price: 'R$ 600',
    tierLabel: 'Mais procurado',
    recommended: true,
    summary:
      'Para quem busca um site completo com múltiplas seções para detalhar serviços e conquistar confiança.',
    features: [
      'Estrutura completa multi-seções ou multi-páginas',
      'Design personalizado alinhado à sua marca',
      'Seções para serviços, diferenciais e dúvidas',
      'Formulário de orçamento com validação',
      'Otimização de velocidade e SEO estruturado',
    ],
    ctaLabel: 'Escolher Plano Médio',
  },
  {
    id: 'premium',
    name: 'Premium',
    optionValue: 'Premium — R$ 1.000',
    price: 'R$ 1.000',
    tierLabel: 'Projeto exclusivo',
    summary:
      'Experiência sob medida com acabamento visual superior, animações refinadas e SEO avançado.',
    features: [
      'Arquitetura sob medida e layout autoral',
      'Animações suaves e micro-interações fluidas',
      'SEO avançado com dados estruturados e OpenGraph',
      'Otimização extrema de performance e imagens',
      'Suporte prioritário nos ajustes finais de lançamento',
    ],
    ctaLabel: 'Escolher Plano Premium',
  },
];

export const WORKFLOW_STEPS: ProcessStep[] = [
  {
    index: '01',
    title: 'Você conta o que faz',
    description:
      'Conversamos de forma direta sobre sua profissão, objetivos e referências para definir o plano ideal.',
  },
  {
    index: '02',
    title: 'Criação e ajustes',
    description:
      'Desenvolvemos o visual, textos estruturados e versão responsiva com espaço para você revisar cada detalhe.',
  },
  {
    index: '03',
    title: 'Site pronto para divulgar',
    description:
      'Entregamos tudo revisado, rápido e configurado para você compartilhar seu link com clientes.',
  },
];
