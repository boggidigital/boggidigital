import { motion, useReducedMotion } from 'motion/react';
import { WORKFLOW_STEPS } from '../data/agencyData';
import { EditorialImage } from './EditorialImage';

export function ProcessSection() {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      id="como-funciona"
      className="border-b border-hairline py-24 lg:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid grid-cols-1 items-stretch gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left: Numbered Editorial Process */}
          <motion.div
            initial={
              prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }
            }
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-6"
          >
            <div>
              <p className="text-sm font-medium tracking-wide text-secondary">
                Sem complicação
              </p>
              <h2 className="mt-3 font-display text-[clamp(2rem,3.6vw,3.25rem)] font-bold leading-[1.08] tracking-tight text-ink">
                Do primeiro papo ao site no ar
              </h2>
            </div>

            <div className="mt-10 divide-y divide-hairline border-y border-hairline">
              {WORKFLOW_STEPS.map((step) => (
                <div
                  key={step.index}
                  className="grid grid-cols-1 gap-2 py-7 sm:grid-cols-12 sm:items-baseline sm:gap-6"
                >
                  <span className="font-mono text-sm font-medium text-brand tabular-nums sm:col-span-2">
                    {step.index}.
                  </span>
                  <div className="sm:col-span-10">
                    <h3 className="font-display text-xl font-semibold tracking-tight text-ink">
                      {step.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-muted sm:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: Editorial Creation Image */}
          <motion.div
            initial={
              prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 16 }
            }
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{
              duration: 0.6,
              delay: prefersReducedMotion ? 0 : 0.08,
              ease: [0.16, 1, 0.3, 1],
            }}
            className="lg:col-span-6"
          >
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl border border-hairline bg-surface lg:aspect-auto lg:h-full lg:min-h-[460px]">
              <EditorialImage
                src="/src/assets/images/service_performance_ads_1794926726780.jpg"
                alt="Profissional configurando interface e métricas de desempenho de um novo site"
                className="h-full w-full object-cover"
              />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-canvas/85 via-canvas/20 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 p-6 lg:p-8">
                <p className="text-xs font-medium text-ink/90">
                  Acompanhamento direto do início à publicação
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
